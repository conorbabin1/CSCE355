import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class CompInt {

	public static void main(String[] args) throws FileNotFoundException {

		//calls comp with 1 argument and intersection with 2	
		if(args.length == 1){
			complement(args[0]);
		}
		else if(args.length == 2){
			preIntersection(args[0], args[1]);
		}
		else{
			System.out.println("Invalid Input");
		}
	}

	public static void complement(String arg) throws FileNotFoundException {
		
		File descDFA = new File(arg);
		
		Scanner scan = new Scanner(descDFA);

		// getting the number of states
		String line1 = scan.nextLine();
		int numStates = Integer.parseInt(line1.substring(line1.lastIndexOf(":") + 2));

		// getting the accepting states
		String line2 = scan.nextLine();
		String[] states = line2.split("\\s");
		int[] accStates = new int[states.length - 2];
		int statesIndex = 2;
		int arrIndex = 0;
		while (statesIndex < states.length) {
			accStates[arrIndex] = Integer.parseInt(states[statesIndex]);
			statesIndex++;
			arrIndex++;
		}

		// getting the alphabet
		String line3 = scan.nextLine();
		char[] alphabet = new char[line3.length() - 10];
		int alphIndex = 10;
		int countIndex = 0;
		while (alphIndex < line3.length()) {
			alphabet[countIndex] = line3.charAt(alphIndex);
			alphIndex++;
			countIndex++;
		}

		// building a matrix for the transition table
		int[][] tranTable = new int[alphabet.length][numStates];
		int index1 = 0;
		int index2 = 0;
		int evenIndex = 0;
		String lines;
		while (index1 < numStates) {
			lines = scan.nextLine();
			evenIndex = 0;
			index2 = 0;
			Scanner scanAll = new Scanner(lines);
			while (index2 < alphabet.length) {
				
				tranTable[index2][index1] = scanAll.nextInt();
				evenIndex += 2;
				index2++;
			}
			index1++;
		}
			
		//printing the complement
		int[] statesList = new int[numStates];
		int popIndex = 0;
		String ret = "";
		System.out.println("Number of states: " + numStates);
		while (popIndex < numStates) {
			statesList[popIndex] = popIndex;
			popIndex++;
		}
		if (numStates > accStates.length) {
			int[] newAcc = new int[numStates - accStates.length];
			int addIndex = 0;
			int charIndex = 0;
			int newCount = 0;

			while (addIndex < numStates) {
				if (!arrContains(accStates, statesList[addIndex])) {
					newAcc[newCount] = statesList[addIndex];
					newCount++;
				}
				addIndex++;
			}
			ret += "Accepting states: ";
			int retIndex = 0;
			while (retIndex < newAcc.length) {
				if(retIndex == 0){
					ret += newAcc[retIndex];
				}
				else{
					ret += " " + newAcc[retIndex];
				}
				retIndex++;
			}
			System.out.println(ret);
		} else {
			String ret1 = "";
			int retIndex1 = 0;
			while (retIndex1 < accStates.length) {
				ret1 += "" + accStates[retIndex1];
				retIndex1++;
			}
			System.out.println(ret1);
		}
		int alphIndex2 = 0;
		System.out.print("Alphabet: ");
		while (alphIndex2 < alphabet.length) {
			System.out.print(alphabet[alphIndex2]);
			alphIndex2++;
		}
		System.out.println("");
		int tran1Index = 0;
		int tran2Index = 0;
		boolean printBool = true;
		while (tran1Index < tranTable[0].length) {
			tran2Index = 0;
			printBool = true;
			while (tran2Index < tranTable.length) {
				if(printBool){
					System.out.print(tranTable[tran2Index][tran1Index]);
					printBool = false;
				}
				else{
					System.out.print(" " + tranTable[tran2Index][tran1Index]);
				}
				tran2Index++;
			}
			System.out.println("");
			tran1Index++;
		}

	}
	//prepares the descriptions to be intersected
	public static void preIntersection(String arg1, String arg2) throws FileNotFoundException {
		
		File descDFA1 = new File(arg1);

		Scanner scan = new Scanner(descDFA1);

		//System.out.println("Enter DFA 1");

		// getting the number of states
		String line1 = scan.nextLine();
		int numStates = Integer.parseInt(line1.substring(line1.lastIndexOf(":") + 2));

		// getting the accepting states
		String line2 = scan.nextLine();
		String[] states = line2.split("\\s");
		int[] accStates = new int[states.length - 2];
		int statesIndex = 2;
		int arrIndex = 0;
		while (statesIndex < states.length) {
			accStates[arrIndex] = Integer.parseInt(states[statesIndex]);
			statesIndex++;
			arrIndex++;
		}

		// getting the alphabet
		String line3 = scan.nextLine();
		char[] alphabet = new char[line3.length() - 10];
		int alphIndex = 10;
		int countIndex = 0;
		while (alphIndex < line3.length()) {
			alphabet[countIndex] = line3.charAt(alphIndex);
			alphIndex++;
			countIndex++;
		}

		// building a matrix for the transition table
		int[][] tranTable = new int[alphabet.length][numStates];
		int index1 = 0;
		int index2 = 0;
		int evenIndex = 0;
		String lines;
		while (index1 < numStates) {
			lines = scan.nextLine();
			evenIndex = 0;
			index2 = 0;
			Scanner scanAll = new Scanner(lines);
			while (index2 < alphabet.length) {
				
				tranTable[index2][index1] = scanAll.nextInt();
				evenIndex += 2;
				index2++;
			}
			index1++;
		}

		//System.out.println("Enter DFA 2");
		
		File descDFA2 = new File(arg2);

		Scanner scan2 = new Scanner(descDFA2);

		// getting the number of states
		String line12 = scan2.nextLine();
		int numStates2 = Integer.parseInt(line12.substring(line12.lastIndexOf(":") + 2));

		// getting the accepting states
		String line22 = scan2.nextLine();
		String[] states2 = line22.split("\\s");
		int[] accStates2 = new int[states2.length - 2];
		int statesIndex2 = 2;
		int arrIndex2 = 0;
		while (statesIndex2 < states2.length) {
			accStates2[arrIndex2] = Integer.parseInt(states2[statesIndex2]);
			statesIndex2++;
			arrIndex2++;
		}

		// getting the alphabet
		String line32 = scan2.nextLine();
		char[] alphabet2 = new char[line32.length() - 10];
		int alphIndex2 = 10;
		int countIndex2 = 0;
		while (alphIndex2 < line32.length()) {
			alphabet2[countIndex2] = line32.charAt(alphIndex2);
			alphIndex2++;
			countIndex2++;
		}

		// building a matrix for the transition table
		int[][] tranTable2 = new int[alphabet2.length][numStates2];
		int index12 = 0;
		int index22 = 0;
		int evenIndex2 = 0;
		String lines2;
		while (index12 < numStates2) {
			lines2 = scan2.nextLine();
			evenIndex2 = 0;
			index22 = 0;
			Scanner scanAll2 = new Scanner(lines2);
			while (index22 < alphabet2.length) {
				
				tranTable2[index22][index12] = scanAll2.nextInt();
				evenIndex2 += 2;
				index22++;
			}
			index12++;
		}
		//call to the actual intersection method
		intersection(numStates, alphabet, accStates, tranTable, numStates2, alphabet2, accStates2, tranTable2);

	}

	public static void intersection(int numS, char[] alph, int[] acc, int[][] tran, int numS2, char[] alph2, int[] acc2, int[][] tran2) {
		int newNumS = numS * numS2;
		int[][] newTran = new int[alph.length][numS * numS2];
		int numSIndex = 0;
		int numS2Index = 0;
		int alphIndex = 0;
		int alphCount = 0;
		//popoulating the new intersected transistion table
		while (alphIndex < alph.length) {
			alphCount = 0;
			numSIndex = 0;
			while (numSIndex < numS) {
				numS2Index = 0;
				while (numS2Index < numS2) {
					newTran[alphIndex][alphCount] = (tran[alphIndex][numSIndex] * numS2) + tran2[alphIndex][numS2Index];
					numS2Index++;
					alphCount++;
				}
				numSIndex++;
			}
			alphIndex++;
		}
		int[] newAccStates = new int[acc.length * acc2.length];
		int FIndex = 0;
		int F2Index = 0;
		int FCount = 0;
		//populating the new accepting states
		while(FIndex < numS){
			F2Index = 0;
			while(F2Index < numS2){
				if(arrContains(acc, FIndex) && arrContains(acc2, F2Index)){
					newAccStates[FCount] = (FIndex * numS2) + F2Index;
					FCount++;
				}
				F2Index++;
			}
			FIndex++;
		}
		//printing the intersected DFA
		System.out.println("Number of states: " + newNumS);
		String ret = "";
		ret += "Accepting states: ";
		int retIndex = 0;
		while (retIndex < newAccStates.length) {
			if(retIndex == 0){
				ret += newAccStates[retIndex];
			}
			else{
				ret += " " + newAccStates[retIndex];
			}
			retIndex++;
		}
		System.out.println(ret);
		int alphIndex2 = 0;
		System.out.print("Alphabet: ");
		while (alphIndex2 < alph.length) {
			System.out.print(alph[alphIndex2]);
			alphIndex2++;
		}
		System.out.println("");
		int tran1Index = 0;
		int tran2Index = 0;
		boolean printBool2 = true;
		while (tran1Index < newTran[0].length) {
			tran2Index = 0;
			printBool2 = true;
			while (tran2Index < newTran.length) {
				if(printBool2){
					System.out.print(newTran[tran2Index][tran1Index]);
					printBool2 = false;
				}
				else{
					System.out.print(" " + newTran[tran2Index][tran1Index]);
				}
				tran2Index++;
			}
			System.out.println("");
			tran1Index++;
		}
	}
	//finds and returns the index of a value in an array
	public static int indexOf(char[] arr, char value) {
		if (arr == null) {
			return -1;
		}
		int len = arr.length;
		int lengthIndex = 0;
		while (lengthIndex < len) {
			if (arr[lengthIndex] == value) {
				return lengthIndex;
			} else {
				lengthIndex++;
			}
		}
		return -1;
	}
	//returns a boolean based on whether an int array contains a value
	public static boolean arrContains(int[] arr, int value) {
		int len = arr.length;
		int lengthIndex = 0;
		while (lengthIndex < len) {
			if (arr[lengthIndex] == value) {
				return true;
			}
			lengthIndex++;
		}
		return false;
	}
	//returns a boolean based on whether a char array contains a value
	public static boolean arrContainsChar(char[] arr, char value) {
		int len = arr.length;
		int lengthIndex = 0;
		while (lengthIndex < len) {
			if (arr[lengthIndex] == value) {
				return true;
			}
			lengthIndex++;
		}
		return false;
	}
}
		

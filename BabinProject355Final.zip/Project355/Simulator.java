import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Simulator {

	public static void main(String[] args) throws FileNotFoundException {

		File descDFA = new File(args[0]);
		
		Scanner scan = new Scanner(descDFA);

		// getting the number of states
		String line1 = scan.nextLine();
		int numStates = Integer.parseInt(line1.substring(line1.lastIndexOf(":") + 2));

		// getting the accepting states
		String line2 = scan.nextLine();
		String[] states = line2.split("\\s");
		int[] accStates = new int[states.length - 2];
		int statesIndex = 2;
		int arrIndex = 0;
		while (statesIndex < states.length) {
			accStates[arrIndex] = Integer.parseInt(states[statesIndex]);
			statesIndex++;
			arrIndex++;
		}

		// getting the alphabet
		String line3 = scan.nextLine();
		char[] alphabet = new char[line3.length() - 10];
		int alphIndex = 10;
		int countIndex = 0;
		while (alphIndex < line3.length()) {
			alphabet[countIndex] = line3.charAt(alphIndex);
			alphIndex++;
			countIndex++;
		}

		// building a matrix for the transition table
		int[][] tranTable = new int[alphabet.length][numStates];
		int index1 = 0;
		int index2 = 0;
		int evenIndex = 0;
		String lines;
		while (index1 < numStates) {
			lines = scan.nextLine();
			evenIndex = 0;
			index2 = 0;
			Scanner scanAll = new Scanner(lines);
			while (index2 < alphabet.length) {
				
				tranTable[index2][index1] = scanAll.nextInt();
				evenIndex += 2;
				index2++;
			}
			index1++;
		}
		File inputDFA = new File(args[1]);
		
		Scanner scan2 = new Scanner(inputDFA);
		ArrayList<String> input = new ArrayList<String>();
		while(scan2.hasNextLine()){
			input.add(scan2.nextLine());
		}
		// simulating the given DFA
		
		simulate(alphabet, accStates, tranTable, input);
	}

	public static void simulate(char[] alph, int[] acc, int[][] tran, ArrayList<String> input) {
		
		int currState = 0;
		int inputLen = 0;
		int inputIndex = 0;
		int arrListIndex = 0;
		while(arrListIndex < input.size()){
			currState = 0;
			inputLen = input.get(arrListIndex).length();
			inputIndex = 0;
			while (inputIndex < inputLen) {
				//updates the current state based on the transition diagram
				currState = tran[indexOf(alph, input.get(arrListIndex).charAt(inputIndex))][currState];
				inputIndex++;
			}
			if (arrContains(acc, currState)) {
				System.out.println("accept");
			} else {
				System.out.println("reject");
			}
			arrListIndex++;
		}


	}
	//finds the index of a value in an array
	public static int indexOf(char[] arr, char value) {
		if (arr == null) {
			return -1;
		}
		int len = arr.length;
		int lengthIndex = 0;
		while (lengthIndex < len) {
			if (arr[lengthIndex] == value) {
				return lengthIndex;
			} else {
				lengthIndex++;
			}
		}
		return -1;
	}
	//returns a boolean based on wheather an int array contains a value
	public static boolean arrContains(int[] arr, int value) {
		int len = arr.length;
		int lengthIndex = 0;
		while (lengthIndex < len) {
			if (arr[lengthIndex] == value) {
				return true;
			}
			lengthIndex++;
		}
		return false;
	}
	//returns a boolean based on wheather a char array contains a value
	public static boolean arrContainsChar(char[] arr, char value) {
		int len = arr.length;
		int lengthIndex = 0;
		while (lengthIndex < len) {
			if (arr[lengthIndex] == value) {
				return true;
			}
			lengthIndex++;
		}
		return false;
	}
}

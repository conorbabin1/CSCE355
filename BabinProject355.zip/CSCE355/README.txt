I implemented the simulator, complement, and intersection problems


The files must be compiled using the javac command and run using the
java command. The Simulator.java file will take two inputs in the form
of the names of .txt files, the description of the DFA and the inputs of
the DFA and will output the resulting list of "accpet"'s or "reject"'s to the
command line. The CompInt.java file will accept either one or two imputs
in the same format as the simulator. If one input is entered the 
complement will be calculated and returned to the command line. If
two inputs are entered, then the resulting intersection will be returned
to the command line. the build/run files are labeled simulator.txt and
boolop.txt
